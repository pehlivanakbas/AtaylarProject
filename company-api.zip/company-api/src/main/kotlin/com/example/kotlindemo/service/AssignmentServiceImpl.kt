package com.example.kotlindemo.service

import com.example.kotlindemo.domain.Assignment
import com.example.kotlindemo.repository.AssignmentRepository
import com.example.kotlindemo.service.base.AssignmentService
import org.springframework.stereotype.Service

@Service
class AssignmentServiceImpl(private val repository: AssignmentRepository): AssignmentService {

    override fun assignProjectToEmployee(assignment: Assignment) {
        repository.save(assignment)
    }


}