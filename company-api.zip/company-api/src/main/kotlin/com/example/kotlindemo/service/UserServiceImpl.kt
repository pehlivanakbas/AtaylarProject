package com.example.kotlindemo.service

import com.example.kotlindemo.domain.User
import com.example.kotlindemo.repository.UserRepository
import com.example.kotlindemo.service.base.UserService
import org.springframework.stereotype.Service

@Service
class UserServiceImpl(private val repository: UserRepository): UserService {

    override fun save(user: User): User {
        return repository.save(user)
    }

    override fun findByPhoneNumber(phoneNumber: String): User? {
        return repository.findByPhoneNumber(phoneNumber)
    }

    override fun findAll(adminId: String): List<User> {
        return repository.findAll().filter { it.adminId == adminId }
    }

}