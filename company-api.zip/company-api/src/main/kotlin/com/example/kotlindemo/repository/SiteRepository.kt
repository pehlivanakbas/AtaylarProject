package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Region
import com.example.kotlindemo.domain.Site
import org.springframework.data.jpa.repository.JpaRepository

interface SiteRepository: JpaRepository<Site, String> {
    fun findByAdminId(id: String): Iterable<Site>
}