package com.example.kotlindemo.web

import com.example.kotlindemo.domain.*
import com.example.kotlindemo.service.base.CustomerService
import com.example.kotlindemo.service.base.ProjectService
import org.springframework.web.bind.annotation.*
import java.util.Locale

@RestController
@RequestMapping("/api/projects")
class ProjectController(private val service: ProjectService){

    @PostMapping("site")
    fun saveSite(@RequestBody site: Site) = service.createSite(site)

    @PostMapping("block")
    fun saveBlock(@RequestBody block: Block) = service.createBlock(block)

    @PostMapping("region")
    fun saveRegion(@RequestBody region: Region) = service.createRegion(region)

    @PostMapping("location")
    fun saveLocation(@RequestBody location: Location) = service.createLocation(location)

    @GetMapping("sites/{id}")
    fun getSites(@PathVariable("id") id: String) = service.findSitesByAdminId(id)

    @GetMapping("blocks/{id}")
    fun getBlocks(@PathVariable("id") id: String) = service.findBlocksByAdminId(id)

    @GetMapping("regions/{id}")
    fun getRegions(@PathVariable("id") id: String) = service.findRegionsByAdminId(id)

    @GetMapping("locations/{id}")
    fun getLocations(@PathVariable("id") id: String) = service.findLocationsByAdminId(id)


}