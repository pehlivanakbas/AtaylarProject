package com.example.kotlindemo.mapper

import com.example.kotlindemo.domain.Customer
import com.example.kotlindemo.service.model.CustomerModel

/*
@Mapper(componentModel = "spring")
interface CustomerMapper {
    fun asDTOFromEntity(customer: Customer?): CustomerModel?
}

 */