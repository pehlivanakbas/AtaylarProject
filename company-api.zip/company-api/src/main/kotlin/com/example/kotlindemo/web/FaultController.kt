package com.example.kotlindemo.web

import com.example.kotlindemo.domain.Fault
import com.example.kotlindemo.domain.Site
import com.example.kotlindemo.service.base.FaultService
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/faults")
class FaultController(private val service: FaultService) {

    @PostMapping("add")
    fun saveFault(@RequestBody fault: Fault) = service.addNewFault(fault)
}