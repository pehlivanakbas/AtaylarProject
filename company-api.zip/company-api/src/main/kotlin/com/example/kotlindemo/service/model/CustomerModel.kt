package com.example.kotlindemo.service.model

data class CustomerModel(
    val firstName: String,
    val lastName: String,
    val id: String?
)