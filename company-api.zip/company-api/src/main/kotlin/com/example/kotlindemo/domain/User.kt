package com.example.kotlindemo.domain

import org.hibernate.annotations.GenericGenerator
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import javax.persistence.*

@Entity
class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column
    var adminId = ""

    @Column
    var name = ""

    @Column(unique = true)
    var phoneNumber = ""

    @Column
    var occupation = ""

    @Column
    var professionalChamber = ""

    @Column
    var registerNo = ""

    @Column
    var tcKimlikNo = ""

    @Column
    var tcKimlikSeriNo = ""

    @Column
    var sskNo = ""

    @Column
    var ownPersonal = true

    @Column
    var userRole = ""

    @Column
    var password = ""
        get() = field
        set(value) {
            field = BCryptPasswordEncoder().encode(value)
        }

    fun comparePassword(password: String) : Boolean {
        return BCryptPasswordEncoder().matches(password, this.password)
    }

}
