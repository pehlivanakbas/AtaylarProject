package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.Fault

interface FaultService {
    fun addNewFault(fault: Fault): Fault
}