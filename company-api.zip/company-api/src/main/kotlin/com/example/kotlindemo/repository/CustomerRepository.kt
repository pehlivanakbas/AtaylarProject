package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Customer
import org.springframework.data.repository.PagingAndSortingRepository

interface CustomerRepository : PagingAndSortingRepository<Customer, String> {
    fun findByLastName(lastName: String): Iterable<Customer>
}