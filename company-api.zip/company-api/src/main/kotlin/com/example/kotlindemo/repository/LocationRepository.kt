package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Location
import com.example.kotlindemo.domain.Site
import org.springframework.data.jpa.repository.JpaRepository

interface LocationRepository: JpaRepository<Location, String> {
    fun findByAdminId(id: String): Iterable<Location>
}