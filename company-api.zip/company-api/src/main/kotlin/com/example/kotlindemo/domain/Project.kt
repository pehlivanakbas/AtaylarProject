package com.example.kotlindemo.domain

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id


@Entity
class Site {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column(unique = true)
    val name = ""

    @Column()
    val adminId = ""
}

@Entity
class Block {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    val id: Int = 0

    @Column()
    val siteId = ""

    @Column()
    val name = ""

    @Column()
    val adminId = ""
}

@Entity
class Region {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column()
    val blockId = ""

    @Column()
    val name = ""

    @Column()
    val adminId = ""
}

@Entity
class Location {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column()
    val regionId = ""

    @Column()
    val name = ""

    @Column()
    val adminId = ""
}