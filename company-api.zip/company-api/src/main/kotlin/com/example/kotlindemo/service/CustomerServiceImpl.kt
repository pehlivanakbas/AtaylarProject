package com.example.kotlindemo.service;

import com.example.kotlindemo.domain.Customer
import com.example.kotlindemo.repository.CustomerRepository
import com.example.kotlindemo.service.base.CustomerService
import com.example.kotlindemo.service.model.CustomerModel
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Service

@Service
class CustomerServiceImpl(private val repository: CustomerRepository) : CustomerService {

    override fun findAll(): List<Customer> {
        return repository.findAll() as List<Customer>;
    }

    override fun saveCustomer(customer: Customer): Customer {
        return repository.save(customer);
    }

    override fun findById(id: String): CustomerModel? {
        val customer = repository.findByIdOrNull(id);
        //return customerMapper.asDTOFromEntity(customer);
        return customer?.let { CustomerModel(it.firstName, customer.lastName, customer.id) };
    }

    override fun updateCustomer(customer: Customer): Customer {
        val oldCustomer = repository.findByIdOrNull(customer.id);
        oldCustomer?.let { repository.delete(it) }
        repository.save(customer)
        return customer
    }

}