package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Fault
import org.springframework.data.jpa.repository.JpaRepository

interface FaultRepository: JpaRepository<Fault, String> {
}