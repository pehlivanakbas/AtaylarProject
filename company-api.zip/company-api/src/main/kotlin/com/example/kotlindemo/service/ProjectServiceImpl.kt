package com.example.kotlindemo.service

import com.example.kotlindemo.domain.*
import com.example.kotlindemo.repository.*
import com.example.kotlindemo.service.base.ProjectService
import org.springframework.stereotype.Service

@Service
class ProjectServiceImpl(
    private val siteRepository: SiteRepository,
    private val blockRepository: BlockRepository,
    private val regionRepository: RegionRepository,
    private val locationRepository: LocationRepository
) : ProjectService {

    override fun createSite(site: Site): Site {
        return siteRepository.save(site)
    }

    override fun createBlock(block: Block): Block {
        return blockRepository.save(block)
    }

    override fun createRegion(region: Region): Region {
        return regionRepository.save(region)
    }

    override fun createLocation(location: Location): Location {
        return locationRepository.save(location)
    }

    override fun findSitesByAdminId(id: String): Iterable<Site> {
       return siteRepository.findByAdminId(id)
    }

    override fun findBlocksByAdminId(id: String): Iterable<Block> {
        return blockRepository.findByAdminId(id)
    }

    override fun findRegionsByAdminId(id: String): Iterable<Region> {
        return regionRepository.findByAdminId(id)
    }

    override fun findLocationsByAdminId(id: String): Iterable<Location> {
        return locationRepository.findByAdminId(id)
    }


}