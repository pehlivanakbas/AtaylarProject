package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Block
import com.example.kotlindemo.domain.Customer
import org.springframework.data.jpa.repository.JpaRepository

interface BlockRepository: JpaRepository<Block, String> {
    fun findByAdminId(id: String): Iterable<Block>
}