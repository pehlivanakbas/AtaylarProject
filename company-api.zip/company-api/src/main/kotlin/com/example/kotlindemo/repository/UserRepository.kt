package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.User
import org.springframework.data.jpa.repository.JpaRepository

interface UserRepository: JpaRepository<User,Int> {
        fun findByPhoneNumber(phoneNumber: String) : User?
}