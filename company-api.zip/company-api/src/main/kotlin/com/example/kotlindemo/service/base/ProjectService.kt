package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.*

interface ProjectService {
    fun createSite(site: Site) : Site
    fun createBlock(block: Block) : Block
    fun createRegion(region: Region) : Region
    fun createLocation(location: Location) : Location
    fun findSitesByAdminId(id: String): Iterable<Site>
    fun findBlocksByAdminId(id: String): Iterable<Block>
    fun findRegionsByAdminId(id: String): Iterable<Region>
    fun findLocationsByAdminId(id: String): Iterable<Location>
}

