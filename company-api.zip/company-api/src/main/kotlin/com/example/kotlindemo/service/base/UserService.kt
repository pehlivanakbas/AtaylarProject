package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.User

interface UserService {
    fun save(user: User): User
    fun findByPhoneNumber(phoneNumber: String): User?
    fun findAll(adminId: String): List<User>
}
