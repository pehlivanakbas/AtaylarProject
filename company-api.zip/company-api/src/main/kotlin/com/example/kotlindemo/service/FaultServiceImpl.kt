package com.example.kotlindemo.service

import com.example.kotlindemo.domain.Fault
import com.example.kotlindemo.repository.FaultRepository
import com.example.kotlindemo.service.base.FaultService
import org.springframework.stereotype.Service

@Service
class FaultServiceImpl(private val repository: FaultRepository): FaultService {
    override fun addNewFault(fault: Fault): Fault {
        return repository.save(fault)
    }
}