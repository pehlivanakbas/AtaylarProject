package com.example.kotlindemo.service.model

data class LoginModel(
    val phoneNumber: String,
    val password: String
)

