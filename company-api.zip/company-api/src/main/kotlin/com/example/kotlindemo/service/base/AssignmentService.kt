package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.Assignment

interface AssignmentService {
    fun assignProjectToEmployee(assignment: Assignment)
}