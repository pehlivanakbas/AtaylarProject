package com.example.kotlindemo.domain

import javax.persistence.*


@Entity
class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column(unique = true)
    var userId = ""

    @Column
    var companyName = ""

    @Column
    var location = ""

    @Column
    var email = ""

    @Column
    var phone = ""

    @Column
    var twitter = ""

    @Column
    var instagram = ""

    @Column
    var facebook = ""

}