package com.example.kotlindemo.web

import com.example.kotlindemo.domain.Customer
import com.example.kotlindemo.service.base.CustomerService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/customers")
class CustomerController(private val service: CustomerService) {

    @GetMapping
    fun findAll() = service.findAll()

    @PostMapping
    fun saveCustomer(@RequestBody customer: Customer) = service.saveCustomer(customer)

    @GetMapping("/{id}")
    fun findById(@PathVariable("id") id: String) = service.findById(id)

    @PutMapping
    fun updateCustomer(@RequestBody customer: Customer) = service.updateCustomer(customer)

}