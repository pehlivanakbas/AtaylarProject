package com.example.kotlindemo.service.model

data class MessageModel (val message: String
)