package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.Customer
import com.example.kotlindemo.service.model.CustomerModel

interface CustomerService {
    fun findAll(): List<Customer>;
    fun saveCustomer(customer: Customer): Customer;
    fun findById(id: String): CustomerModel?;
    fun updateCustomer(customer: Customer): Customer
}