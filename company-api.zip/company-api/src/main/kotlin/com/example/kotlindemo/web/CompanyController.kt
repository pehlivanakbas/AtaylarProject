package com.example.kotlindemo.web

import com.example.kotlindemo.domain.Company
import com.example.kotlindemo.domain.Customer
import com.example.kotlindemo.service.base.CompanyService
import com.example.kotlindemo.service.model.MessageModel
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/api/company")

class CompanyController(private val service: CompanyService) {

    @PostMapping("save")
    fun save(@RequestBody body: Company) : ResponseEntity<Any> {
        service.saveCompany(body)
        return ResponseEntity.ok(MessageModel("success"))
    }

    @PutMapping("update")
    fun updateCompany(@RequestBody body: Company) = service.updateCompany(body)

    @GetMapping("companies")
    fun getALlCompanies() = service.getAllCompanies()

    @GetMapping("/companies/{id}")
    fun findById(@PathVariable("id") id: String) = service.findByUserId(id)

}