package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Company
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.repository.PagingAndSortingRepository

interface CompanyRepository: JpaRepository<Company, String> {
    fun findByUserId(userId: String): Company
}