package com.example.kotlindemo.service.base

import com.example.kotlindemo.domain.Company

interface CompanyService {
    fun saveCompany(company: Company): Company
    fun getAllCompanies() : MutableIterable<Company>
    fun updateCompany(company: Company) : Company
    fun findByUserId(userId: String): Company
}