package com.example.kotlindemo.repository

import com.example.kotlindemo.domain.Block
import com.example.kotlindemo.domain.Region
import org.springframework.data.jpa.repository.JpaRepository

interface RegionRepository: JpaRepository<Region, String> {
    fun findByAdminId(id: String): Iterable<Region>
}