package com.example.kotlindemo.web

import com.example.kotlindemo.domain.Assignment
import com.example.kotlindemo.service.base.AssignmentService
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/assignment")
class AssignmentController(private val service: AssignmentService){

    @PostMapping("assign")
    fun assignProjectToEmployee(@RequestBody assignment: Assignment) = service.assignProjectToEmployee(assignment)
}