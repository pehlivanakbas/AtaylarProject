package com.example.kotlindemo.service

import com.example.kotlindemo.domain.Company
import com.example.kotlindemo.repository.CompanyRepository
import com.example.kotlindemo.repository.CustomerRepository
import com.example.kotlindemo.service.base.CompanyService
import org.springframework.data.repository.findByIdOrNull
import org.springframework.stereotype.Service

@Service
class CompanyServiceImpl(private val repository: CompanyRepository) : CompanyService {

    override fun saveCompany(company: Company): Company {
        return repository.save(company)
    }

    override fun updateCompany(company: Company): Company {
        val oldCompany = repository.findByUserId(company.userId);
        oldCompany.let { repository.delete(it) }
        repository.save(company)
        return company
    }

    override fun getAllCompanies(): MutableIterable<Company> {
        return repository.findAll()
    }

    override fun findByUserId(userId: String): Company {
       return repository.findByUserId(userId)
    }

}