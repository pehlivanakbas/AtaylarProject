package com.example.kotlindemo.web

import com.example.kotlindemo.domain.User
import com.example.kotlindemo.service.base.UserService
import com.example.kotlindemo.service.model.LoginModel
import com.example.kotlindemo.service.model.MessageModel
import io.jsonwebtoken.JwtParser
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.util.*
import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletResponse

@RestController
@RequestMapping("/api/user")
class AuthController(private val service: UserService) {

    @PostMapping("register")
    fun register(@RequestBody body: User) : ResponseEntity<User> {
        return ResponseEntity.ok(service.save(body))
    }

    @PostMapping("login")
    fun login(@RequestBody body: LoginModel, response: HttpServletResponse) : ResponseEntity<Any> {

        val user = service.findByPhoneNumber(body.phoneNumber) ?: return ResponseEntity.badRequest().body(MessageModel("user not found"))

        if(!user.comparePassword(body.password)) {
            return ResponseEntity.badRequest().body(MessageModel("invalid password"))
        }

        val issuer = user.id.toString()

        val jwt = Jwts.builder()
            .setIssuer(issuer)
            .setExpiration(Date(System.currentTimeMillis() + 60 * 24 * 1000)) // 1 day
            .signWith(SignatureAlgorithm.HS512, "secret").compact()

        val cookie = Cookie("jwt", jwt)
        cookie.isHttpOnly = true

        response.addCookie(cookie)

        return ResponseEntity.ok(user)
    }

    @GetMapping("user")
    fun user(@CookieValue("jwt") jwt:String?) : ResponseEntity<Any> {


        if (jwt == null) {
            return ResponseEntity.status(401).body(MessageModel("Unauthorized"))
        }

        val body = Jwts.parser().setSigningKey("secret").parseClaimsJwt(jwt).body

        return ResponseEntity.ok(body)

    }

    @GetMapping("/users/{adminId}")
    fun findById(@PathVariable("adminId") adminId: String) = service.findAll(adminId)

}