package com.example.kotlindemo.domain

import javax.persistence.*

@Entity
class Defect {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Int = 0

    @Column
    val defectNote = ""

    @Column
    val relatedLegislation = ""

}